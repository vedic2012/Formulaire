let compteur = 0;
//recuperation des élément html
const messageInput = document.getElementById('message_input');
const sendButton = document.getElementById('send');
const messageList = document.getElementById('message_list')
//ajout d'un évènement pour le bouton d'envoi
sendButton.addEventListener('click',() =>{
    //recuperation du message saisie
    const message = messageInput.value.trim();
    //verifions si le message n'est pas vide
    if (message){
        //creation d'un nouvel élément de list pour le message
        const messageElement = document.createElement('li');
        messageElement.textContent = message;
        //ajout de l'élément de liste à la liste des éléments
        messageList.appendChild(messageElement);
        if ( compteur % 2 === 0) {
          messageElement.classList.add("left");
          }else{
         messageElement.classList.add("right");
        }
        //vide le champ de saisie
        messageInput.value = '';
        compteur++;
    }
});